//
//  HealHustleApp.swift
//  HealHustle
//
//  Created by Zidan Ramadhan on 21/07/22.
//

import SwiftUI

@main
struct HealHustleApp: App {
    var body: some Scene {
        WindowGroup {
            MainView()
            //CircularTimer()
            //BreakTimeView()
            //TimerView(endRunning: .constant(false))

        }
    }
}
